export const environment = {

  production: false,
  // emptyURL: "http://localhost:1717/attendaceapi/",
  emptyURL: 'https://attendance.abdigitals.co.in:2027/chat_api/',
  secretKey: 'eHNyGuEIhWss2BTIHuseb7ATCFOoRnxR'
}; 