export const environment = {

  production: true,
  emptyURL: 'https://attendance.abdigitals.co.in:2027/chat_api/',

  //  emptyURL: 'http://localhost:1717/attendaceapi/',
 
  secretKey: 'eHNyGuEIhWss2BTIHuseb7ATCFOoRnxR'

};
