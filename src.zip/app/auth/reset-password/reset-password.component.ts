import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { LoginService } from 'src/app/core/services/login.service';
import { first, take, map } from 'rxjs/operators';
import { Observable, timer } from 'rxjs';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})

export class ResetPasswordComponent implements OnInit {
  showOTPForm = false;
  timer$: Observable<number>;            // Timer For Re-Sending OTP
  loginForm: UntypedFormGroup;                // Form Group for Login Form
  submitted: boolean = false;        // Submitted Value for login form errors validations
  error: string = '';           // Error Message Stored value
  returnUrl: string;                   // Return url when user was not login
  public showPassword: boolean = false;  // password toggle for input feild
  intialvalues: any;                      // Form Intial Values For Restting the Form
  otpget: boolean = false;              // Show Form feild after getting otp
  refresh: boolean = false;             // Refresh Boolean Value
  time: any;                              // Time For Showing Otp
  showOverlay: boolean = false;             // Refresh Boolean Value
  loginForms: UntypedFormGroup;


  checkboxChecked: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute, private formBuilder: UntypedFormBuilder, private loginservice: LoginService) { }
  showPasswordForm = true;
  toggleForms() {
    this.showPasswordForm = !this.showPasswordForm;
  }
  ngOnInit(): void {
    this.loginForms = this.formBuilder.group({
      phone: ['', [Validators.required]],
      usr_pwd: ['', [Validators.required]],
      // rememberme: ['']
    });
    this.intialvalues = this.loginForms.value;
  }

  
  numericOnly(event): boolean {
    let patt = /^([0-9])$/;
    let result = patt.test(event.key);
    return result;
  }





  onSubmit1() {
    this.submitted = true;
    if (this.loginForms.invalid) {
      return;
    } else {
      this.loginservice.login1(this.loginForms.value).subscribe(
        data => {
          if (Array.isArray(data) && data.length) {
            Swal.fire({
              position: 'top-end',
              icon: 'success',
              text: 'Login Success',
              showConfirmButton: false,
              timer: 1500
            });
            this.router.navigate([data[0].submenu[0].path]);
          }
        },
        error => {
          this.error = error ? error : '';
        });
      this.submitted = false;
    }
  }
  passwordFieldType: 'password' | 'text' = 'password';

  togglePasswordVisibility() {
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }
}

