import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { LoginService } from 'src/app/core/services/login.service';
import Swal from 'sweetalert2';
import { SidebarService } from '../sidebar/sidebar.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit, OnDestroy {

  // ✅ profile dropdown state
  showProfileMenu = false;

  name: string;

  // ✅ timer cleanup
  private userSub?: Subscription;

  constructor(
    public sidebarservice: SidebarService,
    private loginService: LoginService,
    private router: Router
  ) {
    this.name = localStorage.getItem('usr_nm') || 'User';
    this.userEmail = localStorage.getItem('designations') || '';
    this.rotate();
  }

  toggleSidebar() {
    this.sidebarservice.setSidebarState(!this.sidebarservice.getSidebarState());
  }

  getSideBarState() {
    return this.sidebarservice.getSidebarState();
  }

  hideSidebar() {
    this.sidebarservice.setSidebarState(true);
  }

  ngOnInit() {

    /* Search Bar */
    $(document).ready(function () {
      $(".mobile-search-icon").on("click", function () {
        $(".search-bar").addClass("full-search-bar")
      }),
        $(".search-close").on("click", function () {
          $(".search-bar").removeClass("full-search-bar")
        })
    });

    // ✅ Real-time update (if your LoginService has currentUser BehaviorSubject)
    // If currentUser doesn't exist, it will throw error. In that case comment below 3 lines.
    if ((this.loginService as any)?.currentUser?.subscribe) {
      this.userSub = (this.loginService as any).currentUser.subscribe(() => {
        this.name = localStorage.getItem('usr_nm') || 'User';
      });
    }
  }

  ngOnDestroy(): void {
    // ✅ cleanup
    if (this.id) clearInterval(this.id);
    if (this.userSub) this.userSub.unsubscribe();
  }

  logoutAlert() {
    Swal.fire({
      title: 'Do You Want to Logout',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Do it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.logout();
      }
    })
  }

  logout() {
    this.loginService.logout();
  }

  // ================= CLOCK =================
  hrs: any;
  mins: any;
  secs: any;
  id: any;

  hours: any;
  time: any;
  minutes: any;
  seconds: any;
  ampm: any;

  displayTime() {
    var dateTime = new Date();
    var hours = dateTime.getHours();
    var minutes = dateTime.getMinutes();
    var seconds = dateTime.getSeconds();

    // Convert hours to 12-hour format
    this.ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // Handle midnight (0 hours)

    // Add leading zeros if necessary
    this.hours = hours < 10 ? hours : hours;
    this.minutes = minutes < 10 ? '0' + minutes : minutes;
    this.seconds = seconds < 10 ? '0' + seconds : seconds;

    this.time = hours + ':' + minutes + ':' + seconds + ' ' + this.ampm;
  }

  rotate() {
    this.id = setInterval(() => {
      this.displayTime();
    }, 1000); // Update every second
  }

  // ================= FULLSCREEN =================
  toggleFullScreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  }

  naviagatetobooking() {
    this.router.navigate(['/dashboard/analysis']);
  }

  // ================= ✅ PROFILE DROPDOWN =================
  toggleProfileMenu(ev: MouseEvent) {
    ev.stopPropagation();
    this.showProfileMenu = !this.showProfileMenu;
  }

  @HostListener('document:click')
  closeProfileMenu() {
    this.showProfileMenu = false;
  }
  userEmail: string = '';
  getInitials(fullName: string) {
    const parts = (fullName || '').trim().split(/\s+/).filter(Boolean);
    const a = parts[0]?.[0] || 'U';
    const b = parts.length > 1 ? parts[1][0] : '';
    return (a + b).toUpperCase();
  }

  goProfile() {
    this.showProfileMenu = false;
    this.router.navigate(['profile']); // change if your route is different
  }

  goSettings() {
    this.showProfileMenu = false;
    this.router.navigate(['reports']); // change if your route is different
  }
}