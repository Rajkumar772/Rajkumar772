import { Routes } from '@angular/router';
import { PermissionsGuard } from 'src/app/core/gaurds/permissions.guard';

//Route for content layout with sidebar, navbar and footer.

export const Full_ROUTES: Routes = [
    {
        path: 'permissions',
        loadChildren: () => import('../../modules/permissions/permissions.module').then(m => m.PermissionsModule),
        data: { roles: 3 }, canActivateChild: [PermissionsGuard]
    },


    {
        path: 'dashboard',
        loadChildren: () => import('../../dashboard/dashboard.module').then(m => m.DashboardModule),
        data: { roles: 3 }, canActivateChild: [PermissionsGuard]
    },

    {
        path: 'attendance',
        loadChildren: () => import('../../modules/attendance/attendance.module').then(m => m.AttendanceModule),
        data: { roles: 3 }, canActivateChild: [PermissionsGuard]
    },
    {
        path: 'masters',
        loadChildren: () => import('../../modules/masters/masters.module').then(m => m.MastersModule),
        data: { roles: 3 }, canActivateChild: [PermissionsGuard]
    },
    {
        path: 'marketing',
        loadChildren: () => import('../../modules/marketing/marketing.module').then(m => m.MarketingModule),
        data: { roles: 3 }, canActivateChild: [PermissionsGuard]
    }

];
