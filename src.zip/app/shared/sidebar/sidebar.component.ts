import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { SidebarService } from "./sidebar.service";
import * as $ from 'jquery';
import { LoginService } from 'src/app/core/services/login.service';
import Swal from 'sweetalert2'; // ✅ ADD THIS

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
})
export class SidebarComponent implements OnInit {

  public menuItems: any[] = [];
  public name: string = '';   // ✅ ADD THIS

  constructor(
    public sidebarservice: SidebarService,
    private router: Router,
    private loginService: LoginService
  ) {

    router.events.subscribe((event: Event) => {

      if (event instanceof NavigationStart) {
        // Show loading indicator
      }

      if (
        event instanceof NavigationEnd &&
        $(window).width() < 1025 &&
        (document.readyState == 'complete' || false)
      ) {
        this.toggleSidebar();

      }

      if (event instanceof NavigationError) {
      }
    });
  }

  toggleSidebar() {
    this.sidebarservice.setSidebarState(!this.sidebarservice.getSidebarState());

    if ($(".wrapper").hasClass("nav-collapsed")) {
      // unpin sidebar when hovered
      $(".wrapper").removeClass("nav-collapsed");
      $(".sidebar-wrapper").unbind("hover");
    } else {
      $(".wrapper").addClass("nav-collapsed");
      $(".sidebar-wrapper").hover(
        function () {
          $(".wrapper").addClass("sidebar-hovered");
        },
        function () {
          $(".wrapper").removeClass("sidebar-hovered");
        }
      );
    }
  }

  getSideBarState() {
    return this.sidebarservice.getSidebarState();
  }

  hideSidebar() {
    this.sidebarservice.setSidebarState(true);
  }

  ngOnInit() {
    let sidebardata: any = null;

    if (localStorage.getItem('currentUser')) {
      sidebardata = JSON.parse(localStorage.getItem('currentUser')!);
    } else if (sessionStorage.getItem('currentUser')) {
      sidebardata = JSON.parse(sessionStorage.getItem('currentUser')!);
    }

    this.menuItems = sidebardata;

    // ✅ SET USER NAME FROM STORED USER OBJECT
    if (sidebardata) {
      this.name =
        sidebardata.name ||
        sidebardata.user_name ||
        sidebardata.username ||
        ''; // adjust key if needed
    }

    $.getScript('./assets/js/app-sidebar.js');
  }

  naviagatetobooking() {
    this.router.navigate(['/dashboard/analysis']);
  }

  logoutAlert() {
    Swal.fire({
      title: 'Do You Want to Logout',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Do it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.logout();
      }
    });
  }

  logout() {
    this.loginService.logout();
  }
}
