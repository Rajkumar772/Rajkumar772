
import { CommonModule, DatePipe } from "@angular/common";

import { DashboardRoutingModule } from "./dashboard-routing.module";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { ChartsModule } from 'ng2-charts';
import { NgApexchartsModule } from 'ng-apexcharts';

import { AnalysisComponent } from './analysis/analysis.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { MaterialModule } from '../core/material/material.module';

import { RemoveDuplicateJsonObjectModule } from 'remove-duplicate-json-object';


import { ProfileComponent } from './profile/profile.component';
import { ReportsComponent } from './reports/reports.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";




@NgModule({
    imports: [
        CommonModule,
        DashboardRoutingModule,
        FormsModule,
        ReactiveFormsModule,

    ],
    exports: [],
    declarations: [
        AnalysisComponent,
        ProfileComponent,
        ReportsComponent,
    ],
    providers: [DatePipe],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]   // ✅ IMPORTANT for <emoji-picker>

})
export class DashboardModule { }
