import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ProfileserviceService } from '../profile/profileservice.service';
;

type Tab = 'report' | 'plan';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit, OnDestroy {
  dateLabel = '';

  fromName = '';
  fromInitial = '';

  toName = '';
  toRole = '';
  toInitial = '';

  activeTab: Tab = 'report';
  placeholder = 'Write your report here...';

  @ViewChild('editor', { static: true }) editorRef!: ElementRef<HTMLDivElement>;

  files: File[] = [];
  tasksVisible = false;
  taskOptions: string[] = ['Design review session', 'Sprint planning', 'Client presentation', 'Code refactoring', 'Documentation update'];
  selectedTasks: string[] = [];

  toastVisible = false;
  toastMessage = '';
  private toastTimer: any = null;

  // ✅ logged in user (change key names based on your project)
  empId: string = localStorage.getItem('user_id') || localStorage.getItem('emp_id') || '';
  empName: string = localStorage.getItem('usr_nm') || localStorage.getItem('emp_name') || '';

  // ✅ DB date (use same format you store in attendance_day.att_date)
  attDate = ''; // YYYY-MM-DD

  constructor(private reportApi: ProfileserviceService
  ) { }
  getInitials(name: string): string {
    if (!name) return '';
    const parts = name.trim().split(' ').filter(Boolean);
    const first = parts[0]?.[0] || '';
    const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (first + last).toUpperCase();
  }

  ngOnInit(): void {
    const d = new Date();
    this.dateLabel = d.toLocaleDateString('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    this.attDate = `${yyyy}-${mm}-${dd}`;

    // ✅ FROM = logged in user
    const userId = Number(localStorage.getItem('user_id') || 0);

    if (userId) {
      this.reportApi.getMyProfile(userId).subscribe({
        next: (res) => {
          const u = Array.isArray(res?.data) ? res.data[0] : res?.data; // your API returns array
          const name = u?.name || this.empName || 'User';

          this.fromName = name;
          this.fromInitial = this.getInitials(name) || name[0]?.toUpperCase();

          // ✅ OPTIONAL: If you have supervisor info in profile response
          // Example fields: manager_name, manager_role, manager_id
          if (u?.manager_name) {
            this.toName = u.manager_name;
            this.toRole = u.manager_role || 'Supervisor';
            this.toInitial = this.getInitials(this.toName);
          } else {
            // fallback if no supervisor data
            this.toName = 'Supervisor';
            this.toRole = '';
            this.toInitial = 'S';
          }
        },
        error: () => {
          // fallback
          const fallbackName = this.empName || 'User';
          this.fromName = fallbackName;
          this.fromInitial = this.getInitials(fallbackName) || 'U';

          this.toName = 'Supervisor';
          this.toRole = '';
          this.toInitial = 'S';
        }
      });
    }

    // ✅ Load existing report (already working)
    if (this.empId) {
      this.reportApi.getWorkProgressEvening(this.empId, this.attDate).subscribe({
        next: (res) => {
          const html = res?.data?.work_progress_evening || '';
          if (html && this.editorRef?.nativeElement) {
            this.editorRef.nativeElement.innerHTML = html;
          }
        },
        error: () => { }
      });
    }
  }

  ngOnDestroy(): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
  }

  switchTab(tab: Tab) {
    this.activeTab = tab;
    this.placeholder = tab === 'report' ? 'Write your report here...' : 'Write your plan here...';
    this.focusEditor();
  }

  fmt(cmd: string) {
    this.focusEditor();
    document.execCommand(cmd, false, null);
  }

  insertLink() {
    this.focusEditor();
    const url = prompt('Enter URL');
    if (!url) return;
    document.execCommand('createLink', false, url);
  }

  insertImage() {
    this.focusEditor();
    const url = prompt('Enter image URL');
    if (!url) return;
    document.execCommand('insertImage', false, url);
  }

  toggleHtml() {
    const html = this.editorRef?.nativeElement?.innerHTML || '';
    this.notify(html ? 'HTML copied (check console)' : 'No content');
    
  }

  private focusEditor() {
    const el = this.editorRef?.nativeElement;
    if (!el) return;
    el.focus();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);
  }

  // Files
  onFilesSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    this.files = [...this.files, ...Array.from(input.files)];
    input.value = '';
  }
  removeFile(index: number) {
    this.files.splice(index, 1);
  }

  // Tasks
  toggleTasks() { this.tasksVisible = !this.tasksVisible; }
  isTaskSelected(task: string): boolean { return this.selectedTasks.includes(task); }
  toggleTask(task: string, ev: Event) {
    const checked = (ev.target as HTMLInputElement).checked;
    this.selectedTasks = checked
      ? Array.from(new Set([...this.selectedTasks, task]))
      : this.selectedTasks.filter(x => x !== task);
  }
  removeTask(task: string) { this.selectedTasks = this.selectedTasks.filter(x => x !== task); }

  // ✅ SAVE EVENING REPORT
  saveEveningReport(isDraft: boolean) {
    const html = (this.editorRef?.nativeElement?.innerHTML || '').trim();

    // optional: append tasks info into report html
    const tasksHtml = this.selectedTasks.length
      ? `<hr/><p><b>Tasks:</b> ${this.selectedTasks.map(t => `• ${t}`).join(' ')}</p>`
      : '';

    const finalHtml = `${html}${tasksHtml}`;

    if (!this.empId) {
      this.notify('emp_id not found in storage');
      return;
    }

    this.reportApi.saveWorkProgressEvening({
      emp_id: this.empId,
      emp_name: this.empName,
      att_date: this.attDate,
      work_progress_evening: finalHtml,
      status: 1 // optional
    }).subscribe({
      next: () => this.notify(isDraft ? 'Draft saved!' : '✓ Sent to supervisor!'),
      error: (err) => {
        console.error(err);
        this.notify('Save failed');
      }
    });
  }

  // Toast
  notify(msg: string) {
    this.toastMessage = msg;
    this.toastVisible = true;
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => (this.toastVisible = false), 2200);
  }
}