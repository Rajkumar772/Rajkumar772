export type ChatType = 'group' | 'dm';

export interface ChatItem {
  id: number;
  type: string;
  title: string;
  initials: string;
  meta?: string;
  lastMsg?: string;
  lastTime?: string;
  unread: number;
  online?: boolean;
  color?: string;
  starred?: boolean;
  dayLabel?: string;

  lastIsMe?: boolean;
  lastStatus?: 'sent' | 'delivered' | 'read' | string;

  // ✅ ADD THIS
  selfChat?: boolean;
}
export interface Msg {
  id: number;

  // ✅ add these (because backend returns these + you are using them)
  chatId?: number;
  senderId?: number | null;
  senderName?: string | null;

  me: boolean;
  text: string;

  // ✅ time may be ISO string or Date
  time: string | Date;

    // ✅ attachments (optional)
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime?: string | null;
  attachment_size?: number | null;
}