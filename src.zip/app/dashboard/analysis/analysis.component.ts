import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { ChatItem, Msg } from './chat.models';
import { AnalysisserviceService } from './analysisservice.service';
import { ChatSocketService } from './chat-socket.service';
import Swal from 'sweetalert2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import 'emoji-picker-element';
@Component({
  selector: 'app-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.scss']
})
export class AnalysisComponent implements OnInit {

  showEmoji = false;

  toggleEmoji(ev?: MouseEvent) {
    ev?.stopPropagation();
    this.showEmoji = !this.showEmoji;
  }

  addEmoji(ev: any) {
    // emoji-picker-element => ev.detail.unicode
    const sym =
      ev?.detail?.unicode ||
      ev?.detail?.emoji?.unicode ||
      ev?.emoji?.native ||
      ev?.native ||
      '';

    this.draft = (this.draft || '') + sym;
    this.showEmoji = false;
  }

  @HostListener('document:click')
  closeEmoji() {
    this.showEmoji = false;
  }

  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  @ViewChild('bodyScroll') bodyScroll!: ElementRef<HTMLDivElement>;

  pendingFile: File | null = null;

  openingChat = false;
  searchText = '';
  draft = '';
  activeTab: 'all' | 'unread' | 'groups' | 'starred' = 'all';

  loadingOlder = false;
  hasMore = true;
  pageSize = 50;

  chats: ChatItem[] = [];
  selectedChat!: ChatItem;
  messages: Msg[] = [];

  loadingChats = false;
  loadingMsgs = false;

  casefiledata: any;

  constructor(
    private chatApi: AnalysisserviceService,
    private socketSrv: ChatSocketService
  ) { }

  ngOnInit(): void {
    this.loadChats();
    this.getemployeelist();

    // ✅ socket: new message event
    this.socketSrv.onNewMessage().subscribe((evt: any) => {
      const chatId = Number(evt?.chatId || 0);
      const r = evt?.message;
      if (!chatId || !r) return;

      const idNum = Number(r.id || 0);

      // ✅ hard duplicate guard by message id
      if (idNum && this.seenMsgIds.has(idNum)) return;
      if (idNum) this.seenMsgIds.add(idNum);

      // ✅ If it's my own message (I already added optimistic bubble), just update chat list & return
      const senderIdNum = Number(r.sender_id || 0);
      if (senderIdNum && senderIdNum === this.myUserId) {
        this.loadChats(false);
        return;
      }

      const msg: Msg = {
        id: idNum || Date.now(),
        chatId: r.chat_id,
        text: r.message_text,
        me: false,
        senderName: r.sender_name,
        senderId: senderIdNum,
        time: r.createdAt,

        attachment_url: r.attachment_url,
        attachment_name: r.attachment_name,
        attachment_mime: r.attachment_mime,
        attachment_size: r.attachment_size,
      };

      if (this.selectedChat?.id === chatId) {
        this.replaceOrPushIncoming(chatId, msg);
        setTimeout(() => this.scrollToBottom(), 0);
      } else {
        const chat = this.chats.find(x => x.id === chatId);
        if (chat) chat.unread = (chat.unread || 0) + 1;
      }

      this.loadChats(false);
    });
  }

  // ===================== UI helpers =====================

  get filteredChats(): ChatItem[] {
    const q = (this.searchText || '').toLowerCase().trim();
    let list = [...this.chats];

    if (this.activeTab === 'unread') list = list.filter(x => x.unread > 0);
    if (this.activeTab === 'groups') list = list.filter(x => x.type === 'group');
    if (this.activeTab === 'starred') list = list.filter(x => !!x.starred);

    if (!q) return list;

    return list.filter(c =>
      (c.title || '').toLowerCase().includes(q) ||
      (c.meta || '').toLowerCase().includes(q) ||
      (c.lastMsg || '').toLowerCase().includes(q)
    );
  }

  trackByChatId(_: number, c: ChatItem) { return c.id; }
  trackByMsgId(_: number, m: Msg) { return m.id; }

  private makeInitials(title: string): string {
    const parts = (title || '').trim().split(/\s+/).filter(Boolean);
    const a = (parts[0]?.[0] || '').toUpperCase();
    const b = (parts[1]?.[0] || parts[0]?.[1] || '').toUpperCase();
    return (a + b).slice(0, 2);
  }

  // ===================== Chats =====================

  loadChats(autoSelectFirst: boolean = true) {
    this.loadingChats = true;

    this.chatApi.getChats().subscribe({
      next: (res: any) => {
        this.loadingChats = false;

        const rows = res?.data || [];
        this.chats = rows.map((r: any): any => ({
          id: Number(r.id),
          type: r.type,
          title: r.title,
          initials: this.makeInitials(r.title),
          meta: r.meta || '',
          lastMsg: r.lastMsg || r.last_msg || '',
          lastTime: r.lastTime || r.last_time || '',
          unread: Number(r.unread || 0),
          online: !!r.online,
          color: r.color || 'blue',
          starred: !!r.starred,
          dayLabel: 'TODAY',

          // ✅ these must come from backend getChats API
          lastIsMe: Number(r.last_is_me || 0) === 1,
          lastStatus: r.last_status || 'sent'
        }));
        if (autoSelectFirst && this.chats.length && !this.selectedChat?.id) {
          this.selectChat(this.chats[0]);
        }
      },
      error: () => {
        this.loadingChats = false;
        this.chats = [];
      }
    });
  }

  selectChat(c: ChatItem) {
    if (this.selectedChat?.id) this.socketSrv.leaveChat(this.selectedChat.id);
    this.chatApi.markRead(c.id, Number(localStorage.getItem('user_id') || 0)).subscribe();
    this.selectedChat = c;
    this.socketSrv.joinChat(c.id);

    this.loadMessages(c.id);
  }

  // ===================== Messages =====================

  loadMessages(chatId: number) {
    this.loadingMsgs = true;
    this.hasMore = true;

    this.chatApi.getMessages(chatId, this.pageSize).subscribe({
      next: (res: any) => {
        this.loadingMsgs = false;
        const rows = res?.data || [];

        this.messages = rows.map((r: any) => ({
          id: r.id,
          chatId: r.chat_id,
          text: r.message_text,
          me: Number(r.sender_id) === Number(localStorage.getItem('user_id') || 0),
          senderName: r.sender_name,
          senderId: r.sender_id,
          time: r.createdAt,

          attachment_url: r.attachment_url,
          attachment_name: r.attachment_name,
          attachment_mime: r.attachment_mime,
          attachment_size: r.attachment_size,
        }));

        if (rows.length < this.pageSize) this.hasMore = false;

        setTimeout(() => this.scrollToBottom(), 0);
      },
      error: (err) => {
        this.loadingMsgs = false;
       
      }
    });
  }

  loadOlder() {
    if (this.loadingOlder || !this.hasMore || !this.selectedChat?.id) return;

    const first = this.messages[0];
    const beforeId = first?.id;
    if (!beforeId) return;

    const el = this.bodyScroll?.nativeElement;
    const oldHeight = el?.scrollHeight || 0;

    this.loadingOlder = true;

    this.chatApi.getMessages(this.selectedChat.id, this.pageSize, beforeId).subscribe({
      next: (res: any) => {
        const rows = res?.data || [];

        const older = rows.map((r: any) => ({
          id: r.id,
          chatId: r.chat_id,
          text: r.message_text,
          me: Number(r.sender_id) === Number(localStorage.getItem('user_id') || 0),
          senderName: r.sender_name,
          senderId: r.sender_id,
          time: r.createdAt,

          attachment_url: r.attachment_url,
          attachment_name: r.attachment_name,
          attachment_mime: r.attachment_mime,
          attachment_size: r.attachment_size,
        }));

        if (older.length < this.pageSize) this.hasMore = false;

        // ✅ prepend older messages
        this.messages = [...older, ...this.messages];

        setTimeout(() => {
          const newHeight = el?.scrollHeight || 0;
          if (el) el.scrollTop = newHeight - oldHeight; // keep view position
        }, 0);

        this.loadingOlder = false;
      },
      error: (err) => {
        
        this.loadingOlder = false;
      }
    });
  }

  onBodyScroll() {
    const el = this.bodyScroll?.nativeElement;
    if (!el) return;

    if (el.scrollTop <= 30) {
      this.loadOlder();
    }
  }

  // ===================== Send (Text + File) =====================

  send() {
    const chatId = Number(this.selectedChat?.id || 0);
    if (!chatId) { alert("Select user/chat first"); return; }

    const text = (this.draft || '').trim();
    const fileToUpload = this.pendingFile;

    // nothing to send
    if (!text && !fileToUpload) return;

    const senderIdStr =
      sessionStorage.getItem('user_id') || localStorage.getItem('user_id') || '';
    const senderNameStr =
      localStorage.getItem('usr_nm') || sessionStorage.getItem('usr_nm') || '';

    const senderId = senderIdStr ? Number(senderIdStr) : null;
    const senderName = senderNameStr || null;

    // ✅ optimistic UI
    const tempId = Date.now();
    const optimistic: Msg = {
      id: tempId,
      chatId,
      text: text || (fileToUpload ? fileToUpload.name : ''),
      me: true,
      senderId: senderId ?? 0,
      senderName: senderName ?? 'Me',
      time: new Date().toISOString(),

      attachment_url: null,
      attachment_name: fileToUpload?.name || null,
      attachment_mime: fileToUpload?.type || null,
      attachment_size: fileToUpload?.size || null,
    };

    this.messages.push(optimistic);
    this.draft = '';
    this.clearPendingFile();
    setTimeout(() => this.scrollToBottom(), 0);

    // ✅ TEXT only -> normal sendMessage
    if (!fileToUpload) {
      const payload: any = { text, me: 1, senderId, senderName };

      this.chatApi.sendMessage(chatId, payload).subscribe({
        next: () => this.loadChats(false),
        error: (err) => {
          this.messages = this.messages.filter(m => m.id !== tempId);
          alert(err?.error?.error || err?.error?.message || err?.message || "Send error");
        }
      });
      return;
    }

    // ✅ FILE upload -> upload API already inserts message in DB
    const fd = new FormData();
    fd.append('file', fileToUpload);
    fd.append('text', text || '');
    fd.append('me', '1');
    if (senderId !== null) fd.append('senderId', String(senderId));
    if (senderName) fd.append('senderName', senderName);

    this.chatApi.uploadAttachment(chatId, fd).subscribe({
      next: (up: any) => {
        // backend returns: { status, data:{insertId}, file:{url,name,mime,size}, message:lastRow }
        const file = up?.file;
        const message = up?.message;

        const idx = this.messages.findIndex(m => m.id === tempId);
        if (idx >= 0) {
          this.messages[idx].attachment_url = file?.url || null;
          this.messages[idx].attachment_name = file?.name || this.messages[idx].attachment_name;
          this.messages[idx].attachment_mime = file?.mime || this.messages[idx].attachment_mime;
          this.messages[idx].attachment_size = file?.size || this.messages[idx].attachment_size;

          if (message?.id) this.messages[idx].id = message.id;
        }

        this.loadChats(false);
      },
      error: (err) => {
        this.messages = this.messages.filter(m => m.id !== tempId);
        alert(err?.error?.error || err?.error?.message || err?.message || "Upload error");
      }
    });
  }

  scrollToBottom() {
    const el = this.bodyScroll?.nativeElement;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }

  // ===================== Employee list / openChat =====================

  getemployeelist() {
    this.chatApi.getUserPermissions().subscribe(res => {
      this.casefiledata = res.data;
      
    }, _err => { });
  }

  get leftUsers(): any[] {
  const me = this.myUserId;

  return (this.casefiledata || [])
    .filter((u: any) => Number(u.id) !== me)   // ✅ HIDE SELF (WhatsApp style)
    .map((u: any) => {
      const title = u.name;
      const found: any = (this.chats || []).find(c => (c.title || '') === title);

      return {
        id: u.id,
        title,
        initials: this.makeInitials(title),
        meta: u.role_type || 'User',
        online: true,
        color: 'blue',
        lastMsg: found?.lastMsg || '',
        lastTime: found?.lastTime || '',
        unread: found?.unread || 0,
        delivered: true,
        chatId: found?.id || null
      };
    });
}

  openChat(user: any) {
    this.openingChat = true;
    // ✅ your leftUsers uses "title"
    const title = (user?.title || user?.name || '').trim();
    if (!title) {
      alert('Name missing');
      this.openingChat = false;
      return;
    }

    // ✅ 1) FAST: if already in local chats list, open directly
    const localExisting = (this.chats || []).find(c => (c.title || '').trim() === title);
    if (localExisting) {
      this.selectChat(localExisting);
      this.openingChat = false;
      return;
    }

    // ✅ 2) CHECK SERVER CHATS (to avoid duplicates)
    this.chatApi.getChats().subscribe({
      next: (res: any) => {
        const chats = res?.data || [];
        const existing = chats.find((x: any) => (x.title || '').trim() === title);

        if (existing) {
          const chat: ChatItem = {
            id: Number(existing.id),
            type: existing.type || 'dm',
            title: existing.title,
            initials: this.makeInitials(existing.title),
            meta: existing.meta || '',
            lastMsg: existing.lastMsg || existing.last_msg || '',
            lastTime: existing.lastTime || existing.last_time || '',
            unread: Number(existing.unread || 0),
            online: !!existing.online,
            color: existing.color || 'blue',
            starred: !!existing.starred,
            dayLabel: 'TODAY'
          };

          this.selectChat(chat);
          this.openingChat = false;
          return;
        }

        // ✅ 3) CREATE NEW CHAT (only if not exists)
    const payload = { title, type: 'dm', meta: 'Online', members: [Number(user.id)] };

        this.chatApi.createChat(payload).subscribe({
          next: (newChat: any) => {
            const chatId = Number(newChat?.data?.insertId || newChat?.data?.chatId || 0);
            if (!chatId) {
              alert("Chat create failed (no chatId/insertId)");
              this.openingChat = false;
              return;
            }

            const chat: ChatItem = {
              id: chatId,
              type: 'dm',
              title,
              initials: this.makeInitials(title),
              meta: 'Online',
              lastMsg: '',
              lastTime: '',
              unread: 0,
              online: true,
              color: 'blue',
              starred: false,
              dayLabel: 'TODAY'
            };

            this.selectChat(chat);
            this.loadChats(false);
            this.openingChat = false;
          },
          error: (err) => {
            
            alert(err?.error?.error || err?.message || "Create chat error");
            this.openingChat = false;
          }
        });
      },
      error: (err) => {
        
        alert("Get chats error");
        this.openingChat = false;
      }
    });
  }

  // ===================== File picker =====================

  pickFile() {
    this.fileInput?.nativeElement?.click();
  }

  onFileSelected(e: Event) {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0] || null;
    if (!file) return;

    // limit 10MB
    if (file.size > 10 * 1024 * 1024) {
      alert('File too large (max 10MB)');
      input.value = '';
      return;
    }

    this.pendingFile = file;
  }

  clearPendingFile() {
    this.pendingFile = null;
    if (this.fileInput?.nativeElement) this.fileInput.nativeElement.value = '';
  }


  private replaceOrPushIncoming(chatId: number, msg: Msg) {
    if (this.selectedChat?.id !== chatId) return;

    // ✅ if incoming is attachment, replace temp bubble (same file name + same sender)
    if (msg.attachment_url) {
      const tempIdx = this.messages.findIndex((m: any) =>
        m.chatId === chatId &&
        (m as any)._temp === true &&
        (m.attachment_name || '') === (msg.attachment_name || '') &&
        Number(m.senderId || 0) === Number(msg.senderId || 0)
      );

      if (tempIdx >= 0) {
        this.messages[tempIdx] = msg; // replace temp with real
        return;
      }
    }

    // otherwise normal push
    this.messages.push(msg);
  }

  niceMime(m: any): string {
    const t = String(m || '').toLowerCase();
    if (!t) return 'file';
    if (t.includes('pdf')) return 'PDF';
    if (t.includes('word')) return 'DOC';
    if (t.includes('excel') || t.includes('sheet')) return 'XLS';
    if (t.includes('zip') || t.includes('rar')) return 'ZIP';
    if (t.includes('image')) return 'IMAGE';
    return t.split('/').pop()?.toUpperCase() || 'FILE';
  }

  formatBytes(bytes: any): string {
    const b = Number(bytes || 0);
    if (!b) return '0 KB';
    const kb = b / 1024;
    if (kb < 1024) return `${Math.round(kb)} KB`;
    const mb = kb / 1024;
    return `${mb.toFixed(1)} MB`;
  }

  fileExt(m: any): string {
    const n = (m?.attachment_name || '').toLowerCase();
    const ext = n.includes('.') ? n.split('.').pop() : '';
    return (ext || 'file').toUpperCase();
  }

  isPdf(m: any): boolean {
    const t = (m?.attachment_mime || '').toLowerCase();
    const n = (m?.attachment_name || '').toLowerCase();
    return t.includes('pdf') || n.endsWith('.pdf');
  }
  isDoc(m: any): boolean {
    const n = (m?.attachment_name || '').toLowerCase();
    return n.endsWith('.doc') || n.endsWith('.docx');
  }
  isZip(m: any): boolean {
    const n = (m?.attachment_name || '').toLowerCase();
    return n.endsWith('.zip') || n.endsWith('.rar');
  }


  isRecording = false;
  recSeconds = 0;

  private mediaRecorder: MediaRecorder | null = null;
  private recChunks: BlobPart[] = [];
  private recTimer: any = null;
  private recStream: MediaStream | null = null;

  // ✅ start recording
  async startVoice() {
    const chatId = Number(this.selectedChat?.id || 0);
    if (!chatId) { alert("Select user/chat first"); return; }
    if (this.isRecording) return;

    try {
      // ask mic permission
      this.recStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // choose supported mime
      const mime =
        MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' :
          MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' :
            '';

      this.recChunks = [];
      this.mediaRecorder = new MediaRecorder(this.recStream, mime ? { mimeType: mime } : undefined);

      this.mediaRecorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) this.recChunks.push(e.data);
      };

      this.mediaRecorder.onstop = async () => {
        try {
          const blob = new Blob(this.recChunks, { type: this.mediaRecorder?.mimeType || 'audio/webm' });
          this.recChunks = [];

          // stop tracks
          this.recStream?.getTracks().forEach(t => t.stop());
          this.recStream = null;

          // ignore too short recordings (< 0.5s)
          if (blob.size < 1500) return;

          // create file
          const ext = (blob.type.includes('webm') ? 'webm' : 'wav');
          const file = new File([blob], `voice-${Date.now()}.${ext}`, { type: blob.type });

          // ✅ optimistic message bubble (audio attachment)
          const tempId = Date.now();
          const optimistic: any = {
            id: tempId,
            chatId,
            text: '🎤 Voice message',
            me: true,
            senderId: Number(sessionStorage.getItem('user_id') || localStorage.getItem('user_id') || 0),
            senderName: localStorage.getItem('usr_nm') || sessionStorage.getItem('usr_nm') || 'Me',
            time: new Date().toISOString(),
            attachment_url: null,
            attachment_name: file.name,
            attachment_mime: file.type,
            attachment_size: file.size
          };
          this.messages.push(optimistic);
          setTimeout(() => this.scrollToBottom(), 0);

          // ✅ upload using your existing uploadAttachment API
          const fd = new FormData();
          fd.append('file', file);
          fd.append('text', '');      // optional
          fd.append('me', '1');

          const senderIdStr = sessionStorage.getItem('user_id') || localStorage.getItem('user_id') || '';
          const senderNameStr = localStorage.getItem('usr_nm') || sessionStorage.getItem('usr_nm') || '';
          if (senderIdStr) fd.append('senderId', senderIdStr);
          if (senderNameStr) fd.append('senderName', senderNameStr);

          this.chatApi.uploadAttachment(chatId, fd).subscribe({
            next: (up: any) => {
              const fileRes = up?.file;
              const message = up?.message;

              const idx = this.messages.findIndex(m => m.id === tempId);
              if (idx >= 0) {
                this.messages[idx].attachment_url = fileRes?.url || null;
                if (message?.id) this.messages[idx].id = message.id;
              }
              this.loadChats(false);
            },
            error: (err) => {
              this.messages = this.messages.filter(m => m.id !== tempId);
              alert(err?.error?.error || err?.error?.message || err?.message || "Voice upload error");
            }
          });

        } finally {
          this.isRecording = false;
          this.recSeconds = 0;
          if (this.recTimer) clearInterval(this.recTimer);
          this.recTimer = null;
        }
      };

      this.isRecording = true;
      this.recSeconds = 0;
      this.recTimer = setInterval(() => this.recSeconds++, 1000);

      this.mediaRecorder.start();

    } catch (e: any) {
      this.isRecording = false;
      alert("Microphone permission denied or not available.");
    }
  }

  // ✅ stop recording
  stopVoice() {
    if (!this.isRecording) return;

    try {
      this.mediaRecorder?.stop();
    } catch { }

    this.isRecording = false;
    if (this.recTimer) clearInterval(this.recTimer);
    this.recTimer = null;
  }

private myUserId = Number(
  sessionStorage.getItem('user_id') ||
  localStorage.getItem('user_id') || 0
);

  private seenMsgIds = new Set<number>(); // ✅ prevent duplicate by id

  isChatOpen = false;

openChatMobile() {
  // ✅ only open in mobile width
  if (window.innerWidth <= 560) this.isChatOpen = true;
}
closeChatMobile() {
  if (window.innerWidth <= 560) {
    this.isChatOpen = false;   // ✅ show list
    this.selectedChat = null;  // optional
  }
}
}