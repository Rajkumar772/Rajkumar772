import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ChatSocketService {

  private socket!: Socket;

  connect() {
    if (this.socket?.connected) return;
    const base = environment.emptyURL.replace('/dashboardapi/', '');
    const token =
      localStorage.getItem('token') ||
      sessionStorage.getItem('token') ||
      localStorage.getItem('raju30') ||
      sessionStorage.getItem('raju30') ||
      '';

    this.socket = io(base, {
      transports: ['websocket'],
      auth: { token }
    });
  }

  joinChat(chatId: number) {
    this.connect();
    // kept for backward compatibility
    this.socket.emit('join_chat', chatId);
  }

  leaveChat(chatId: number) {
    if (!this.socket) return;
    this.socket.emit('leave_chat', chatId);
  }

  onNewMessage(): Observable<any> {
    this.connect();
    return new Observable(observer => {
      this.socket.on('new_message', (data) => observer.next(data));
      return () => this.socket.off('new_message');
    });
  }
}
