import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AnalysisserviceService {
  // ✅ keep your env as it is: "http://localhost:1717/dashboardapi/"
  private baseUrl = environment.emptyURL;          // ends with "/"
  private PermissionApi = environment.emptyURL;    // ends with "/"

  alertShown: boolean = false;

  constructor(private http: HttpClient) { }

  // ✅ helper to avoid // in url without changing env
  private url(path: string): string {
    // baseUrl already ends with "/", so DO NOT add "/" in path
    return `${this.baseUrl}${path}`;
  }

  // ✅ READ ALL CHATS
  getChats(): Observable<{ status: number; data: any[] }> {
    return this.http
      .get<{ status: number; data: any[] }>(this.url('chats'))
      .pipe(catchError(this.handleHttpError));
  }

  // ✅ READ MESSAGES BY CHAT ID
getMessages(chatId: number, limit = 50, beforeId?: number) {
  let url = this.url(`chats/${chatId}/messages?limit=${limit}`);
  if (beforeId) url += `&beforeId=${beforeId}`;
  return this.http.get<{ status: number; data: any[] }>(url)
    .pipe(catchError(this.handleHttpError));
}
  // ✅ SEND MESSAGE
  sendMessage(
    chatId: number,
    payload: { text: string; me?: number; senderId?: number | null; senderName?: string | null }
  ): Observable<any> {
    return this.http
      .post(this.url(`chats/${chatId}/messages`), payload)
      .pipe(catchError(this.handleHttpError));
  }

  // ✅ CREATE CHAT
  createChat(payload: { title: string; type: string; meta?: string; members?: number[] }): Observable<any> {
    return this.http
      .post(this.url('chats'), payload)
      .pipe(catchError(this.handleHttpError));
  }

  // ✅ USER LIST (your existing API)
  getUserPermissions(): Observable<any> {
    return this.http.get<any>(this.PermissionApi + `getUserPermissions`).pipe(
      map(res => this.handleResponse(res)),
      catchError(this.handleHttpError)
    );
  }

  // ✅ your existing auth handling
  private handleResponse(res: any) {
    if ((res.status === 401 || res.status === 403) && !this.alertShown) {
      this.alertShown = true;
      alert(res.msg);
      return null;
    }
    return res;
  }

  // ✅ common http error logger (helps you debug 500)
  private handleHttpError(err: HttpErrorResponse) {
    return throwError(() => err);
  }

uploadAttachment(chatId: number, fd: FormData) {
  return this.http.post(this.url(`chats/${chatId}/upload`), fd)
    .pipe(catchError(this.handleHttpError));
}

markRead(chatId:number, userId:number){
  return this.http.post(this.url(`chats/${chatId}/read`), { userId });
}


}