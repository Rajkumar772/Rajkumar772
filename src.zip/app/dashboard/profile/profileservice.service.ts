import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProfileserviceService {
  private baseUrl = environment.emptyURL;

  constructor(private http: HttpClient) { }

  getMyProfile(userId: number) {
    return this.http.get<any>(`${this.baseUrl}/profile/${userId}`);
  }

  saveWorkProgressEvening(data: {
    emp_id: string | number;
    emp_name?: string;
    att_date: string;
    work_progress_evening: string;

    // ✅ add this
    status?: number;
  }) {
    return this.http.post<any>(`${this.baseUrl}/work-progress/evening`, data);
  }

  getWorkProgressEvening(emp_id: string | number, att_date: string) {
    return this.http.get<any>(`${this.baseUrl}/work-progress/evening/${emp_id}/${att_date}`);
  }

  getSupervisor(userId: number) {
    return this.http.get<any>(`${this.baseUrl}/supervisor/${userId}`);
  }
 
}