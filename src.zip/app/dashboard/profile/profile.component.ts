import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ProfileserviceService } from './profileservice.service';

type Status = 'Active' | 'Inactive';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  myformgroup: UntypedFormGroup;
  photoPreview = '';  // keep if your HTML uses it
  userId: number = Number(localStorage.getItem('user_id') || 0);

  constructor(
    private fb: UntypedFormBuilder,
    private profileApi: ProfileserviceService
  ) {
    // ✅ No validators needed since we are only displaying
    this.myformgroup = this.fb.group({
      fullname: [''],
      employeeId: [''],
      role: [''],
      department: [''],
      email: [''],
      mobile: [''],
      status: ['Active' as Status],
      photo_url: ['']
    });
  }

  ngOnInit(): void {
    this.loadProfile();
  }

  get f() {
    return this.myformgroup.controls as any;
  }

  // ✅ ONLY GET DATA AND SHOW IN UI
  loadProfile(): void {
    if (!this.userId) {
      console.warn('❌ user_id missing in localStorage');
      return;
    }

    this.profileApi.getMyProfile(this.userId).subscribe({
      next: (res: any) => {
        // expecting: { status:200, data:[{...}] }
        let data = res?.data ?? res;
        if (Array.isArray(data)) data = data[0];

        if (!data) return;

        this.myformgroup.patchValue({
          fullname: data?.name ?? '',
          employeeId: data?.emp_id ?? '',
          role: [data?.role_type, data?.designations].filter(Boolean).join(' - '),
          department: data?.department ?? '',
          email: data?.email ?? '',   // if not in DB, stays empty
          mobile: data?.number ?? '',
          status: (data?.d_in == 0 ? 'Active' : 'Inactive') as Status,
          photo_url: data?.photo_url ?? ''
        });

        // if you store photo_url later
        if (data?.photo_url) this.photoPreview = data.photo_url;
      },
      error: (err) => {
        console.error('❌ Profile API error:', err);
      }
    });
  }

  // ✅ keep for UI initials
  initials(name?: string): string {
    if (!name) return 'U';
    const p = name.trim().split(/\s+/);
    return ((p[0]?.[0] || '') + (p[p.length - 1]?.[0] || '')).toUpperCase();
  }

  toggleEdit(){}
}