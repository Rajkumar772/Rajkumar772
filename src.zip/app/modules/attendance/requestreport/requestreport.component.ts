import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AttendanceserviceService } from '../attendanceservice.service';



@Component({
  selector: 'app-requestreport',
  templateUrl: './requestreport.component.html',
  styleUrls: ['./requestreport.component.scss']
})
export class RequestreportComponent implements OnInit {
  loading: boolean = false;
  submitted: boolean = false;
  dataSource: MatTableDataSource<any>;     // Datasource For Mable to assign array
  @ViewChild(MatPaginator) paginator: MatPaginator;      // Mat Table Pagination selector
  @ViewChild(MatSort) sort: MatSort;                     // Mat Table Sorting selector
  initialValues;                           // Intial values for form

  nextdisplayedColumns: string[] = ['i', 'employeeId', 'employeeName', 'leaveType', 'session', 'startDate', 'endDate', 'numberOfDays', 'reason', 'createdAt', 'status', 'statuspending'];

  selectColumns: string[] = ['selectSlno'];
  hideselect: boolean = false;
  reset: any = ''
  masterdata: any = [];
  clonedata: any[] = [];
  cust_color: string = 'blue';


  headerclass = {
    fontSize: '17px',
    fontWeight: '500',
    backgroundColor: 'dodgerblue',
    color: 'white',
    paddingTop: '4px',
    paddingBottom: '4px',
    lineHeight: '1.1'
  }
  constructor(private service: AttendanceserviceService) {
    this.empId = localStorage.getItem('emp_id');

  }
  empId: any;
  role_type: any;
  ngOnInit(): void {
    this.getdesignation();
    this.role_type = localStorage.getItem('role_type');
    this.setDisplayedColumns();
  }
  setDisplayedColumns() {
    if (this.role_type === 'Admin') {
      this.nextdisplayedColumns = [
        'i',
        'employeeId',
        'employeeName',
        'leaveType',
        'session',
        'startDate',
        'endDate',
        'numberOfDays',
        'reason',
        'createdAt',
        'status',
        'statuspending'
      ];
    } else {
      this.nextdisplayedColumns = [
        'i',
        'employeeId',
        'employeeName',
        'leaveType',
        'session',
        'startDate',
        'endDate',
        'numberOfDays',
        'reason',
        'createdAt',
        'status'
      ];
    }
  }
  //table code Star
  applyFilter(event: any) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  originalandtoggle(index) {
    if (index) {
      this.hideselect = !this.hideselect;
    } else {
      this.hideselect = false;
      this.headerclass['background-color'] = 'blue';
      this.reset = '';
    }
    this.clonedata = this.masterdata;
    this.dataSource = new MatTableDataSource(this.clonedata);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = null;
    this.dataSource.sort = this.sort;
  }

  columnfilterdata(object, index) {
    if (object == undefined) {
      this.clonedata = this.masterdata;
      this.reset = '';
    } else {
      if (index == 0) {
        this.clonedata = this.clonedata.filter(self => {
          return self[object.key] === object.value;
        })
      }
    }
    this.dataSource = new MatTableDataSource(this.clonedata);
  }

  changecolor(colorclass) {
    this.headerclass['background-color'] = colorclass;
  }

  changeCustomColor(event) {
    this.headerclass['background-color'] = event.target.value;
  }

  departments: any;
  getdesignation() {
    var data = {
      'role_type': this.role_type,
      'empId': this.empId
    }
    this.service.getrequestreport(data).subscribe(res => {
      this.loading = false;
      res.data.map((res, index) => {
        res.i = ++index;
      })
      this.masterdata = res.data;
      this.clonedata = this.masterdata;
      this.dataSource = new MatTableDataSource(res.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.loading = false;
    })
  }

  statusList = [
    { label: 'Approved', value: 'APPROVED' },
    { label: 'Rejected', value: 'REJECTED' }
  ];

  getStatusLabel(status: any): string {
    const s = (status || '').toString().trim().toUpperCase();

    if (s === 'APPROVED') return 'Approved';
    if (s === 'REJECTED') return 'Rejected';
    return 'Pending';
  }

  getStatusClass(status: any): string {
    const s = (status || '').toString().trim().toUpperCase();

    if (s === 'APPROVED') return 'approved-badge';
    if (s === 'REJECTED') return 'rejected-badge';
    return 'pending-badge';
  }


  onStatusChange(row: any) {
    const payload = {
      id: row.id,
      status: row.status
    };
    this.showSpinner = true;
    this.service.updateLeaveStatus(payload).subscribe(
      (res: any) => {
        this.showSpinner = false;

        if (res && res.status === 200) {

        } else {
          alert('Failed to update status');
        }
      },
      (err) => {
        this.showSpinner = false;
        console.error(err);
        alert('Something went wrong');
      }
    );
  }
  showSpinner: boolean = false;
  review: any;

}