import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestreportComponent } from './requestreport.component';

describe('RequestreportComponent', () => {
  let component: RequestreportComponent;
  let fixture: ComponentFixture<RequestreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestreportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
