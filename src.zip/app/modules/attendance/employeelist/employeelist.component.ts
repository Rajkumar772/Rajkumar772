import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AttendanceserviceService } from '../attendanceservice.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.scss']
})
export class EmployeelistComponent implements OnInit {
  empId: any;
  role_type: any;
  todayList: any[] = [];
  todayRow: any = null;
  loading = false;
  msg = '';
  submitted: boolean = false;
  dataSource: MatTableDataSource<any>;     // Datasource For Mable to assign array
  @ViewChild(MatPaginator) paginator: MatPaginator;      // Mat Table Pagination selector
  @ViewChild(MatSort) sort: MatSort;                     // Mat Table Sorting selector
  initialValues;                           // Intial values for form
  edit: boolean = false;                   // Edit value for

  nextdisplayedColumns: string[] = ['i', 'department', 'designations', 'emp_name', 'att_date', 'clock_in', 'lunch_out', 'lunch_in', 'evening_out', 'work_hours', 'work_progress_evening', 'location', 'clockin_photo'];

  selectColumns: string[] = [];
  hideselect: boolean = false;
  reset: any = ''
  masterdata: any = [];
  appointmentreport: any;
  clonedata: any[] = [];
  cust_color: string = 'blue';
  variable: any;
  newOccupationForm: any;
  age: any;
  headerclass = {
    fontSize: '17px',
    fontWeight: '500',
    backgroundColor: 'dodgerblue',
    color: 'white',
    paddingTop: '4px',
    paddingBottom: '4px',
    lineHeight: '1.1'
  }


  roletype: any;
  constructor(private attSrv: AttendanceserviceService, private modalService: NgbModal) {

  }

  ngOnInit(): void {
    this.empId = localStorage.getItem('emp_id');
    this.role_type = localStorage.getItem('role_type');
    this.getemployeelist()
  }


  showSpinner: boolean = false;
  casefiledata: any = [];
  ////report starts

  getemployeelist() {
    var data = {
      'role_type': this.role_type,
      'empId': this.empId
    }
    this.attSrv.getattendancereport(data).subscribe(res => {
      this.showSpinner = false;
      this.casefiledata = res.data;
      res.data.map((res, index) => {
        res.i = ++index;
      })
      this.masterdata = res.data;
      this.clonedata = this.masterdata;
      this.dataSource = new MatTableDataSource(res.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.showSpinner = false;
    })
  }

  //table code Star
  applyFilter(event: any) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  originalandtoggle(index) {
    if (index) {
      this.hideselect = !this.hideselect;
    } else {
      this.hideselect = false;
      this.headerclass['background-color'] = 'blue';
      this.reset = '';
    }
    this.clonedata = this.masterdata;
    this.dataSource = new MatTableDataSource(this.clonedata);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = null;
    this.dataSource.sort = this.sort;
  }

  columnfilterdata(object, index) {
    if (object == undefined) {
      this.clonedata = this.masterdata;
      this.reset = '';
    } else {
      if (index == 0) {
        this.clonedata = this.clonedata.filter(self => {
          return self[object.key] === object.value;
        })
      }
    }
    this.dataSource = new MatTableDataSource(this.clonedata);
  }

  changecolor(colorclass) {
    this.headerclass['background-color'] = colorclass;
  }

  changeCustomColor(event) {
    this.headerclass['background-color'] = event.target.value;
  }



  parseWorkHoursToMinutes(value: any): number | null {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number' && !isNaN(value)) {
      return Math.round(value * 60);
    }
    const s = String(value).trim();
    if (/^\d+(\.\d+)?$/.test(s)) {
      const hours = parseFloat(s);
      if (!isNaN(hours)) return Math.round(hours * 60);
    }
    const parts = s.split(':').map(p => p.trim());
    if (parts.length >= 2) {
      const h = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      if (!isNaN(h) && !isNaN(m)) return h * 60 + m;
    }

    return null;
  }

  workHoursClass(workHours: any): string {
    const mins = this.parseWorkHoursToMinutes(workHours);
    if (mins === null) return 'wh-na';

    const eight = 8 * 60;
    const nine = 9 * 60;

    if (mins === eight) return 'wh-ok';        // exactly 8h -> green
    if (mins < eight) return 'wh-low';         // below 8h -> red
    if (mins >= nine) return 'wh-high';        // 9h and above -> orange

    return 'wh-mid'; // 8:01 to 8:59 (optional style)
  }

  formatWorkHours(workHours: any): string {
    const mins = this.parseWorkHoursToMinutes(workHours);
    if (mins === null) return '-';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    const hh = String(h).padStart(2, '0');
    const mm = String(m).padStart(2, '0');
    return `${hh}:${mm}`;
  }
  openLocation(lat: string | number, lng: string | number): void {
    if (!lat || !lng) {
      return;
    }
    const url = `https://www.google.com/maps?q=${lat},${lng}`;
    window.open(url, '_blank');
  }

  selectedImage: string = '';

  openImageModal(imageUrl: string, content: any): void {
    this.selectedImage = imageUrl;
    this.modalService.open(content, {
      size: 'lg',
      centered: true,
      backdrop: 'static'
    });
  }
}

