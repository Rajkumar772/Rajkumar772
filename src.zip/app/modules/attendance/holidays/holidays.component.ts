import {
  AfterViewInit,
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import {
  MatCalendar,
  MatCalendarCellCssClasses
} from '@angular/material/datepicker';
import { AttendanceserviceService } from '../attendanceservice.service';
import { Subscription } from 'rxjs';

type HolidayType = 'Holiday' | 'Optional' | 'Event';

export interface Holiday {
  id?: number;
  holiday_date: string;
  title: string;
  holiday_type: HolidayType;
}

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.scss']
})
export class HolidaysComponent implements OnInit, AfterViewInit {
  @ViewChild('calendar') calendar!: MatCalendar<Date>;

  selectedDate: Date = new Date();

  viewYear = new Date().getFullYear();
  viewMonth = new Date().getMonth() + 1;

  loading = false;

  holidays: Holiday[] = [];
  filteredHolidays: Holiday[] = [];

  private calendarStateSub!: Subscription;
  private lastActiveMonth!: number;
  private lastActiveYear!: number;

  monthNames: string[] = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  constructor(private attendanceservice: AttendanceserviceService) { }

  ngOnInit(): void {
    const today = new Date();
    this.selectedDate = today;
    this.viewYear = today.getFullYear();
    this.viewMonth = today.getMonth() + 1;

    // default current month load
    this.loadHolidaysByMonth(this.viewYear, this.viewMonth);
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.calendar) {
        this.lastActiveMonth = this.calendar.activeDate.getMonth() + 1;
        this.lastActiveYear = this.calendar.activeDate.getFullYear();

        this.calendarStateSub = this.calendar.stateChanges.subscribe(() => {
          const activeMonth = this.calendar.activeDate.getMonth() + 1;
          const activeYear = this.calendar.activeDate.getFullYear();

          if (
            activeMonth !== this.lastActiveMonth ||
            activeYear !== this.lastActiveYear
          ) {
            this.lastActiveMonth = activeMonth;
            this.lastActiveYear = activeYear;

            this.viewMonth = activeMonth;
            this.viewYear = activeYear;

            this.loadHolidaysByMonth(this.viewYear, this.viewMonth);
          }
        });
      }
    });
  }

  loadHolidaysByMonth(year: number, month: number): void {
    this.loading = true;

    const payload = {
      year: year,
      month: month
    };

    this.attendanceservice.getHolidaysByMonth(payload).subscribe({
      next: (res: any) => {
        this.loading = false;

        if (res && res.status === 200 && Array.isArray(res.data)) {
          this.holidays = res.data.map((item: any) => ({
            id: item.id,
            holiday_date: this.formatApiDate(item.holiday_date),
            title: item.title,
            holiday_type: item.holiday_type
          }));

          this.filteredHolidays = [...this.holidays];
        } else {
          this.holidays = [];
          this.filteredHolidays = [];
        }

        setTimeout(() => {
          if (this.calendar) {
            this.calendar.updateTodaysDate();
          }
        });
      },
      error: (err) => {
        this.loading = false;
        console.error('Error loading holidays:', err);
        this.holidays = [];
        this.filteredHolidays = [];
      }
    });
  }

  onDateSelected(date: Date): void {
    this.selectedDate = date;
  }

  dateClass = (date: Date): MatCalendarCellCssClasses => {
    const formattedDate = this.formatDate(date);
    const holiday = this.holidays.find(h => h.holiday_date === formattedDate);

    if (!holiday) {
      return '';
    }

    if (holiday.holiday_type === 'Holiday') {
      return 'holiday-date';
    }

    if (holiday.holiday_type === 'Optional') {
      return 'optional-date';
    }

    if (holiday.holiday_type === 'Event') {
      return 'event-date';
    }

    return 'holiday-date';
  };

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  formatApiDate(dateStr: string): string {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) {
      return dateStr;
    }
    return this.formatDate(d);
  }

  getHolidayBadgeClass(type: string): string {
    switch (type) {
      case 'Holiday':
        return 'badge-holiday';
      case 'Optional':
        return 'badge-optional';
      case 'Event':
        return 'badge-event';
      default:
        return 'badge-holiday';
    }
  }

  ngOnDestroy(): void {
    if (this.calendarStateSub) {
      this.calendarStateSub.unsubscribe();
    }
  }
}