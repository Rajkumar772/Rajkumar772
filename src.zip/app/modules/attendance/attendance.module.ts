import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttendanceRoutingModule } from './attendance-routing.module';
import { PersonattendanceComponent } from './personattendance/personattendance.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { RemoveDuplicateJsonObjectModule } from 'remove-duplicate-json-object';
import { MaterialModule } from 'src/app/core/material/material.module';
import { LeaverequestComponent } from './leaverequest/leaverequest.component';
import { RequestreportComponent } from './requestreport/requestreport.component';
import { HolidaysComponent } from './holidays/holidays.component';


@NgModule({
  declarations: [
    PersonattendanceComponent,
    EmployeelistComponent,
    LeaverequestComponent,
    RequestreportComponent,
    HolidaysComponent
  ],
  imports: [
    CommonModule,
    AttendanceRoutingModule,
    FormsModule,
    NgSelectModule,
    ReactiveFormsModule,
    MaterialModule,
    RemoveDuplicateJsonObjectModule
  ]
})
export class AttendanceModule { }
