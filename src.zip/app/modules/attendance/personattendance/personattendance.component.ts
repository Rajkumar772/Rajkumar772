import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AttendanceserviceService } from '../attendanceservice.service';
import Swal from 'sweetalert2';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';

type PunchType = 'clock_in' | 'lunch_out' | 'lunch_in' | 'evening_out';
type CamType = 'clock_in' | 'evening_out';

@Component({
  selector: 'app-personattendance',
  templateUrl: './personattendance.component.html',
  styleUrls: ['./personattendance.component.scss']
})
export class PersonattendanceComponent implements OnInit {

  empId: any;
  empName: any;
  department: any;
  designations: any;
  role_type: any;
  todayList: any[] = [];
  todayRow: any = null;
  loading = false;
  msg = '';
  @ViewChild('video', { static: false }) videoRef?: ElementRef<HTMLVideoElement>;
  @ViewChild('canvas', { static: false }) canvasRef?: ElementRef<HTMLCanvasElement>;
  camType: CamType = 'clock_in';
  showCam = false;
  capturedDataUrl: string | null = null;
  private stream: MediaStream | null = null;


  ///report code starts
  submitted: boolean = false;
  dataSource: MatTableDataSource<any>;     // Datasource For Mable to assign array
  @ViewChild(MatPaginator) paginator: MatPaginator;      // Mat Table Pagination selector
  @ViewChild(MatSort) sort: MatSort;                     // Mat Table Sorting selector
  initialValues;                           // Intial values for form
  edit: boolean = false;                   // Edit value for
  // nextdisplayedColumns: string[] = ['i', 'roomtype', 'edit', 'delete'];
  nextdisplayedColumns: string[] = [
    'i', 'department', 'designations', 'emp_name', 'att_date', 'clock_in', 'lunch_out', 'lunch_in', 'evening_out', 'work_hours',
    'work_progress_evening'
  ];

  selectColumns: string[] = ['selectSlno', 'select1', 'select2', 'select3', 'select4', 'select5', 'select6', 'select7', 'select8', 'select9', 'select10'];
  hideselect: boolean = false;
  reset: any = ''
  masterdata: any = [];
  appointmentreport: any;
  clonedata: any[] = [];
  cust_color: string = 'blue';
  variable: any;
  newOccupationForm: any;
  age: any;
  headerclass = {
    fontSize: '17px',
    fontWeight: '500',
    backgroundColor: 'dodgerblue',
    color: 'white',
    paddingTop: '4px',
    paddingBottom: '4px',
    lineHeight: '1.1'
  }


  roletype: any;
  constructor(private attSrv: AttendanceserviceService) {

  }

  ngOnInit(): void {
    this.empId = localStorage.getItem('emp_id');
    this.empName = localStorage.getItem('usr_nm');
    this.department = localStorage.getItem('department');
    this.designations = localStorage.getItem('designations');
    this.role_type = localStorage.getItem('role_type');
    this.loadToday();
    this.getroomtypedata();
    this.getCurrentLocation();
  }

  // =========================
  // ✅ LOAD TODAY
  // =========================
  loadToday(): void {
    const data = { emp_id: this.empId, att_date: this.todayDate() };

    this.attSrv.getToday(data).subscribe({
      next: (res: any) => {
        const raw = res?.data;
        this.todayList = Array.isArray(raw) ? raw : (raw ? [raw] : []);
        this.todayRow = this.todayList.length
          ? this.todayList.reduce((a, b) => (Number(a.id) > Number(b.id) ? a : b))
          : null;
      },
      error: () => {
        this.todayList = [];
        this.todayRow = null;
      }
    });
  }

  // =========================
  // ✅ BUTTON ENABLE RULES
  // =========================
  canMorningIn(): boolean { return !this.todayRow?.clock_in; }
  canLunchOut(): boolean { return !!this.todayRow?.clock_in && !this.todayRow?.lunch_out; }
  canLunchIn(): boolean { return !!this.todayRow?.lunch_out && !this.todayRow?.lunch_in; }
  canEveningOut(): boolean { return !!this.todayRow?.lunch_in && !this.todayRow?.evening_out; }

  // =========================
  // ✅ BUTTON CLICKS
  // =========================
  onMorningIn(): void {
    if (!this.canMorningIn()) {
      Swal.fire({ icon: 'info', title: 'Already punched', text: `Clock In at ${this.timeOnly(this.todayRow?.clock_in)}` });
      return;
    }
    this.openCam('clock_in');
  }

  onLunchOut(): void {
    if (!this.canLunchOut()) {
      Swal.fire({ icon: 'warning', title: 'Not allowed', text: 'Lunch OUT enabled only after Clock In' });
      return;
    }
    this.punchOnly('lunch_out');
  }

  onLunchIn(): void {
    if (!this.canLunchIn()) {
      Swal.fire({ icon: 'warning', title: 'Not allowed', text: 'Lunch IN enabled only after Lunch OUT' });
      return;
    }
    this.punchOnly('lunch_in');
  }

  onEveningOut(): void {
    if (!this.canEveningOut()) {
      Swal.fire({ icon: 'warning', title: 'Not allowed', text: 'Clock Out enabled only after Lunch IN' });
      return;
    }
    this.openCam('evening_out'); // ✅ updated
  }




  workProgress: string = '';


  openCam(type: 'clock_in' | 'evening_out') {
    this.camType = type;
    this.showCam = true;
    this.capturedDataUrl = null;
    this.workProgress = '';

    setTimeout(() => {
      this.startCamera();
    }, 150);
  }

  closeCam() {
    this.stopCamera();
    this.showCam = false;
    this.capturedDataUrl = null;
    this.workProgress = '';
  }

  async startCamera() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
      });

      const video = this.videoRef?.nativeElement;
      if (video) {
        video.srcObject = this.stream;
        video.play();
      }

    } catch (err) {
      this.showCam = false;
      Swal.fire('Camera Error', 'Unable to access camera', 'error');
    }
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  }

  capture() {
    if (!this.videoRef || !this.canvasRef) return;

    const video = this.videoRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    this.capturedDataUrl = canvas.toDataURL('image/jpeg', 0.7);

    this.stopCamera();
  }

  retake() {
    this.capturedDataUrl = null;
    setTimeout(() => this.startCamera(), 150);
  }


  async uploadCaptured(): Promise<void> {

    if (!this.capturedDataUrl) {
      Swal.fire('Warning', 'Please capture photo first', 'warning');
      return;
    }

    // ✅ Only require work progress for evening_out
    if (this.camType === 'evening_out' && !this.workProgress.trim()) {
      Swal.fire('Warning', 'Please enter your work progress', 'warning');
      return;
    }

    // ✅ Get Location Before Punch
    try {
      const loc = await this.getCurrentLocation();
      this.latitude = loc.latitude;
      this.longitude = loc.longitude;
    } catch (err: any) {
      Swal.fire({
        icon: 'warning',
        title: 'Location Required',
        text: err || 'Please allow location permission to punch',
        confirmButtonText: 'OK'
      });
      return;
    }

    const payload: any = {
      emp_id: this.empId,
      emp_name: this.empName,
      att_date: this.todayDate(),
      punch_type: this.camType,
      punch_time: this.nowTime(),
      department: this.department,
      designations: this.designations,
      role_type: this.role_type,
      photo_base64: this.capturedDataUrl,

      // ✅ lat long
      latitude: this.latitude,
      longitude: this.longitude
    };

    if (this.camType === 'evening_out') {
      payload.work_progress = this.workProgress.trim();
    }

    this.loading = true;

    this.attSrv.punch(payload).subscribe({
      next: () => {
        this.loading = false;
        this.closeCam();
        Swal.fire('Success', 'Punch saved successfully', 'success');
        this.loadToday();
      },
      error: (err) => {
        this.loading = false;
        const serverMsg = err?.error?.message || err?.message || 'Punch failed';
        Swal.fire('Error', serverMsg, 'error');
      }
    });
  }

  private async punchOnly(type: PunchType): Promise<void> {
    this.loading = true;

    // ✅ Get Location Before Punch
    try {
      const loc = await this.getCurrentLocation();
      this.latitude = loc.latitude;
      this.longitude = loc.longitude;
    } catch (err: any) {
      this.loading = false;
      Swal.fire({
        icon: 'warning',
        title: 'Location Required',
        text: err || 'Please allow location permission to punch',
        confirmButtonText: 'OK'
      });
      return;
    }

    const payload: any = {
      emp_id: this.empId,
      emp_name: this.empName,
      att_date: this.todayDate(),
      punch_type: type,
      punch_time: this.nowTime(),
      department: this.department,
      designations: this.designations,
      role_type: this.role_type,

      // ✅ lat long
      latitude: this.latitude,
      longitude: this.longitude
    };

    this.attSrv.punch(payload).subscribe({
      next: (res: any) => {
        this.loading = false;
        Swal.fire({
          icon: 'success',
          title: 'Saved',
          text: res?.message || 'Punch saved',
          timer: 1000,
          showConfirmButton: false
        });
        this.loadToday();
      },
      error: (err) => {
        this.loading = false;
        const code = err?.status;
        const serverMsg = err?.error?.message || err?.message || 'Punch failed';
        Swal.fire({ icon: 'error', title: `Failed (HTTP ${code || '-'})`, text: serverMsg });
      }
    });
  }


  dateOnly(datetime: string | Date | null): string {
    if (!datetime) return '--/--/----';
    const d = new Date(datetime);
    if (isNaN(d.getTime())) return '--/--/----';
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }


  // =========================
  // ✅ HELPERS
  // =========================
  todayDate(): string {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  nowTime(): string {
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    return `${hh}:${mi}`;
  }

  timeOnly(v: any): string {
    if (!v) return '--:--';
    const s = String(v);
    if (s.includes(' ')) return (s.split(' ')[1] || '').substring(0, 5);
    if (s.includes('T')) return (s.split('T')[1] || '').substring(0, 5);
    return s.substring(0, 5);
  }

  showSpinner: boolean = false;
  casefiledata: any = [];
  ////report starts
  getroomtypedata() {
    var data = {
      'role_type': this.role_type,
      'empId': this.empId
    }
    this.attSrv.getattendancereport(data).subscribe(res => {
      this.showSpinner = false;
      this.casefiledata = res.data;
      res.data.map((res, index) => {
        res.i = ++index;
      })
      this.masterdata = res.data;
      this.clonedata = this.masterdata;
      this.dataSource = new MatTableDataSource(res.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.showSpinner = false;
    })
  }

  //table code Star
  applyFilter(event: any) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  originalandtoggle(index) {
    if (index) {
      this.hideselect = !this.hideselect;
    } else {
      this.hideselect = false;
      this.headerclass['background-color'] = 'blue';
      this.reset = '';
    }
    this.clonedata = this.masterdata;
    this.dataSource = new MatTableDataSource(this.clonedata);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = null;
    this.dataSource.sort = this.sort;
  }

  columnfilterdata(object, index) {
    if (object == undefined) {
      this.clonedata = this.masterdata;
      this.reset = '';
    } else {
      if (index == 0) {
        this.clonedata = this.clonedata.filter(self => {
          return self[object.key] === object.value;
        })
      }
    }
    this.dataSource = new MatTableDataSource(this.clonedata);
  }

  changecolor(colorclass) {
    this.headerclass['background-color'] = colorclass;
  }

  changeCustomColor(event) {
    this.headerclass['background-color'] = event.target.value;
  }

  latitude: number | null = null;
  longitude: number | null = null;
  locationError: string = '';
  getCurrentLocation(): Promise<{ latitude: number; longitude: number }> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        this.locationError = "Geolocation not supported";
        return reject(this.locationError);
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          this.latitude = pos.coords.latitude;
          this.longitude = pos.coords.longitude;
          resolve({ latitude: this.latitude!, longitude: this.longitude! });
        },
        (err) => {
          this.locationError = err?.message || "Location permission denied";
          reject(this.locationError);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  }

}

