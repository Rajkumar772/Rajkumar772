import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonattendanceComponent } from './personattendance.component';

describe('PersonattendanceComponent', () => {
  let component: PersonattendanceComponent;
  let fixture: ComponentFixture<PersonattendanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonattendanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonattendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
