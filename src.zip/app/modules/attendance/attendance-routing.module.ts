import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonattendanceComponent } from './personattendance/personattendance.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { LeaverequestComponent } from './leaverequest/leaverequest.component';
import { RequestreportComponent } from './requestreport/requestreport.component';
import { HolidaysComponent } from './holidays/holidays.component';

const routes: Routes = [
  { path: 'personattendance', component: PersonattendanceComponent, data: { roles: 3 } },
  { path: 'employeelist', component: EmployeelistComponent, data: { roles: 4 } },
  { path: 'leaverequest', component: LeaverequestComponent, data: { roles: 5 } },
  { path: 'requestreport', component: RequestreportComponent, data: { roles: 8 } },
  { path: 'holidays', component: HolidaysComponent, data: { roles: 9 } }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AttendanceRoutingModule { }
