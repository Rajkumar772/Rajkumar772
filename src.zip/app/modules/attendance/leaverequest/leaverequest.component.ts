import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators, UntypedFormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AttendanceserviceService } from '../attendanceservice.service';
type LeaveSession = 'FULL' | 'HALF_AM' | 'HALF_PM';

@Component({
  selector: 'app-leaverequest',
  templateUrl: './leaverequest.component.html',
  styleUrls: ['./leaverequest.component.scss']
})
export class LeaverequestComponent implements OnInit {

  submitting = false;
  minDate = this.toISODate(new Date());

  file: File | null = null;
  fileName = '';

  daysValue = 0;
  daysText = '0';

  dateRangeError = false;

  leaveTypes = [
    { label: 'Vacation Leave', value: 'VACATION' },
    { label: 'Sick Leave', value: 'SICK' },
    { label: 'Casual Leave', value: 'CASUAL' },
    { label: 'Maternity Leave', value: 'MATERNITY' },
    { label: 'Paternity Leave', value: 'PATERNITY' },
    { label: 'Work From Home', value: 'WFH' },
    { label: 'Loss of Pay', value: 'LOP' },
  ];

  form: UntypedFormGroup;
  private sub = new Subscription();

  constructor(private fb: UntypedFormBuilder,
    private leaveApi: AttendanceserviceService) {

    this.form = this.fb.group({
      employeeName: ['', [Validators.required, Validators.minLength(3)]],
      employeeId: ['', [Validators.required]],
      leaveType: ['', [Validators.required]],
      session: ['FULL' as LeaveSession, [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      reason: ['', [Validators.required]],
      contact: [''],
    });
  }

  ngOnInit(): void {
    this.sub.add(
      this.form.valueChanges.subscribe(() => {
        this.enforceSessionRules();   // ✅ first enforce rules
        this.calculateDays();         // ✅ then compute days
      })
    );
    this.enforceSessionRules();
    this.calculateDays();
    this.empId = localStorage.getItem('emp_id');
    this.employeeName = localStorage.getItem('usr_nm');
  }

  employeeName: any;
  empId: any;
  isInvalid(ctrlName: string): boolean {
    const c = this.form.get(ctrlName);
    return !!(c && c.touched && c.invalid);
  }

  onFileChange(ev: Event): void {
    const input = ev.target as HTMLInputElement;
    const f = input.files && input.files.length ? input.files[0] : null;

    this.file = null;
    this.fileName = '';

    if (!f) return;

    const allowed = ['application/pdf', 'image/png', 'image/jpeg'];
    if (allowed.indexOf(f.type) === -1) {
      alert('Only PDF, JPG, PNG allowed');
      input.value = '';
      return;
    }

    const maxMB = 5;
    if (f.size > maxMB * 1024 * 1024) {
      alert(`File size must be <= ${maxMB} MB`);
      input.value = '';
      return;
    }

    this.file = f;
    this.fileName = f.name;
  }

  private calculateDays(): void {
    const startRaw = this.form.get('startDate')?.value;
    const endRaw = this.form.get('endDate')?.value;
    const session = (this.form.get('session')?.value || 'FULL') as LeaveSession;

    const start = startRaw ? String(startRaw) : '';
    const end = endRaw ? String(endRaw) : '';

    this.dateRangeError = false;

    if (!start || !end) {
      this.daysValue = 0;
      this.daysText = '0';
      return;
    }

    const s = new Date(start);
    const e = new Date(end);

    if (isNaN(s.getTime()) || isNaN(e.getTime())) {
      this.daysValue = 0;
      this.daysText = '0';
      return;
    }

    if (e.getTime() < s.getTime()) {
      this.dateRangeError = true;
      this.daysValue = 0;
      this.daysText = '0';
      return;
    }

    const dayMs = 24 * 60 * 60 * 1000;
    const diff = Math.round((this.stripTime(e).getTime() - this.stripTime(s).getTime()) / dayMs);
    let days = diff + 1;

    if (session !== 'FULL') {
      // ✅ now HALF is always single day because enforceSessionRules() fixed it
      days = 0.5;
    }

    this.daysValue = days;

    // show clean text
    this.daysText = (days === 0.5) ? '0.5 day' : `${days} day(s)`;
  }
  get isMultiDayRange(): boolean {
    const start = this.form.get('startDate')?.value;
    const end = this.form.get('endDate')?.value;
    if (!start || !end) return false;

    const s = this.stripTime(new Date(start));
    const e = this.stripTime(new Date(end));
    if (isNaN(s.getTime()) || isNaN(e.getTime())) return false;

    const dayMs = 24 * 60 * 60 * 1000;
    const days = Math.round((e.getTime() - s.getTime()) / dayMs) + 1;
    return days > 1;
  }
  // ✅ REAL API SUBMIT (NO DUMMY)
  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    if (this.dateRangeError) return;

    var data = {
      employeeName: this.employeeName,
      employeeId: this.empId,
      leaveType: this.form.value.leaveType,
      session: this.form.value.session,
      startDate: this.form.value.startDate,
      endDate: this.form.value.endDate,
      reason: this.form.value.reason,
      contact: this.form.value.contact,
      numberOfDays: this.daysValue,
      attachmentName: this.fileName || null,
      createdAt: new Date().toISOString(),
      status: 'PENDING'
    };

    this.submitting = true;

    this.leaveApi.createLeave(data).subscribe({
      next: (res) => {
        this.submitting = false;
        alert('Leave request submitted!');
        this.resetForm();
      },
      error: (err) => {
        this.submitting = false;
        console.error('Leave create error:', err);
        alert('Failed to submit leave request');
      }
    });
  }

  resetForm(): void {
    this.form.reset({
      employeeName: '',
      // employeeId: '',
      leaveType: '',
      session: 'FULL',
      startDate: '',
      endDate: '',
      reason: '',
      contact: ''
    });

    this.file = null;
    this.fileName = '';
    this.daysValue = 0;
    this.daysText = '0';
    this.dateRangeError = false;
  }

  cancel(): void {
    this.resetForm();
  }

  private stripTime(d: Date): Date {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  private toISODate(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }


  private enforcing = false;

  private enforceSessionRules(): void {
    if (this.enforcing) return;

    const session = (this.form.get('session')?.value || 'FULL') as LeaveSession;
    const start = this.form.get('startDate')?.value;
    const end = this.form.get('endDate')?.value;

    if (!start || !end) return;

    // Normalize dates (yyyy-mm-dd)
    const s = this.stripTime(new Date(start));
    const e = this.stripTime(new Date(end));

    if (isNaN(s.getTime()) || isNaN(e.getTime())) return;

    const dayMs = 24 * 60 * 60 * 1000;
    const days = Math.round((e.getTime() - s.getTime()) / dayMs) + 1;
    if (session !== 'FULL' && days > 1) {
      this.enforcing = true;
      this.form.patchValue({ session: 'FULL' }, { emitEvent: false });
      this.enforcing = false;
      return;
    }
    if (session !== 'FULL' && start !== end) {
      this.enforcing = true;
      this.form.patchValue({ endDate: start }, { emitEvent: false });
      this.enforcing = false;
    }
  }
}