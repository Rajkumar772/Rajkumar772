import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentsComponent } from './departments/departments.component';
import { DesignationComponent } from './designation/designation.component';

const routes: Routes = [
  { path: 'departments', component: DepartmentsComponent, data: { roles: 6 } },
  { path: 'designation', component: DesignationComponent, data: { roles: 7 } }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
