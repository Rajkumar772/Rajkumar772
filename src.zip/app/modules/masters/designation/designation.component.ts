import { Component, OnInit, ViewChild } from '@angular/core';
import { Validators, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
import { MasterserviceService } from '../masterservice.service';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.scss']
})
export class DesignationComponent {

  loading: boolean = false;
  deptForm: UntypedFormGroup;

  ///report code starts
  submitted: boolean = false;
  dataSource: MatTableDataSource<any>;     // Datasource For Mable to assign array
  @ViewChild(MatPaginator) paginator: MatPaginator;      // Mat Table Pagination selector
  @ViewChild(MatSort) sort: MatSort;                     // Mat Table Sorting selector
  initialValues;                           // Intial values for form
  edit: boolean = false;                   // Edit value for

  nextdisplayedColumns: string[] = [
    'i', 'department', 'designations'];

  selectColumns: string[] = ['selectSlno', 'select1'];
  hideselect: boolean = false;
  reset: any = ''
  masterdata: any = [];
  appointmentreport: any;
  clonedata: any[] = [];
  cust_color: string = 'blue';
  variable: any;
  newOccupationForm: any;
  age: any;
  headerclass = {
    fontSize: '17px',
    fontWeight: '500',
    backgroundColor: 'dodgerblue',
    color: 'white',
    paddingTop: '4px',
    paddingBottom: '4px',
    lineHeight: '1.1'
  }
  constructor(private fb: UntypedFormBuilder, private service: MasterserviceService) {

  }

  ngOnInit(): void {
    this.deptForm = this.fb.group({
      department_name: ['', [Validators.required]],
      designation_name: ['', [Validators.required]],
    });
    this.getdepartments();
    this.getdesignation();
  }
  get f() { return this.deptForm.controls; }

  resetForm(): void {
    this.deptForm.reset({
      department_name: '',

    });
  }

  submit(): void {
    if (this.deptForm.invalid) {
      this.deptForm.markAllAsTouched();
      return;
    }
    this.loading = true;
    var data = {
      department_name: this.deptForm.value.department_name,
      designation_name: this.deptForm.value.designation_name
    }
    this.service.addDesignation(data).subscribe({
      next: (res: any) => {
        this.loading = false;
        Swal.fire({
          icon: 'success',
          title: 'Saved',
          text: res?.message || 'saved',
          timer: 1200,
          showConfirmButton: false
        });
        this.closeModal();

      },
      error: (err) => {
        this.loading = false;
        const code = err?.status;
        const serverMsg = err?.error?.message || err?.error?.error?.message || err?.message || 'failed';
        Swal.fire({
          icon: 'error',
          title: `Failed (HTTP ${code || '-'})`,
          text: serverMsg
        });
      }
    });
  }
  showModal = false;
  openModal(): void {
    this.showModal = true;
    this.resetForm(); // optional: clear old values
  }
  closeModal(): void {
    this.showModal = false;
  }



  //table code Star
  applyFilter(event: any) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  originalandtoggle(index) {
    if (index) {
      this.hideselect = !this.hideselect;
    } else {
      this.hideselect = false;
      this.headerclass['background-color'] = 'blue';
      this.reset = '';
    }
    this.clonedata = this.masterdata;
    this.dataSource = new MatTableDataSource(this.clonedata);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = null;
    this.dataSource.sort = this.sort;
  }

  columnfilterdata(object, index) {
    if (object == undefined) {
      this.clonedata = this.masterdata;
      this.reset = '';
    } else {
      if (index == 0) {
        this.clonedata = this.clonedata.filter(self => {
          return self[object.key] === object.value;
        })
      }
    }
    this.dataSource = new MatTableDataSource(this.clonedata);
  }

  changecolor(colorclass) {
    this.headerclass['background-color'] = colorclass;
  }

  changeCustomColor(event) {
    this.headerclass['background-color'] = event.target.value;
  }

  departments: any;
  getdesignation() {
    this.service.getdesignation().subscribe(res => {
      this.loading = false;
      res.data.map((res, index) => {
        res.i = ++index;
      })
      this.masterdata = res.data;
      this.clonedata = this.masterdata;
      this.dataSource = new MatTableDataSource(res.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.loading = false;
    })
  }

  getdepartments() {
    this.service.getdepartments().subscribe(res => {
      this.loading = false;
      this.departments = res.data;
    }, error => {
      this.loading = false;
    })
  }



}