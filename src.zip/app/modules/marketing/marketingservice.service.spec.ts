import { TestBed } from '@angular/core/testing';

import { MarketingserviceService } from './marketingservice.service';

describe('MarketingserviceService', () => {
  let service: MarketingserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MarketingserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
