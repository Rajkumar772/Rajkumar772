import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MarketingComponent } from './marketing/marketing.component';
import { LeadsComponent } from './leads/leads.component';

const routes: Routes = [
  { path: 'marketing', component: MarketingComponent, data: { roles: 10 } },
  { path: 'leads', component: LeadsComponent, data: { roles: 13 } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MarketingRoutingModule { }
