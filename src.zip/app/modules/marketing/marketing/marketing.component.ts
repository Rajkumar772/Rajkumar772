import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { MarketingserviceService } from '../marketingservice.service';

@Component({
  selector: 'app-marketing',
  templateUrl: './marketing.component.html',
  styleUrls: ['./marketing.component.scss']
})
export class MarketingComponent implements OnInit {

  submitting = false;
  file: File | null = null;
  fileName = '';

  HospitalTypes = [
    { label: 'Hospital', value: 'Hospital' },
    { label: 'Clinic', value: 'Clinic' },
    { label: 'Diagnostic Center', value: 'DiagnosticCenter' },
    { label: 'Pharmacy', value: 'Pharmacy' },
    { label: 'Nursing Home', value: 'NursingHome' },
    { label: 'Others', value: 'Others' },

  ];

  LevelTypes = [
    { label: 'low', value: 'low' },
    { label: 'medium', value: 'medium' },
    { label: 'High', value: 'High' },


  ];

  form: UntypedFormGroup;
  private sub = new Subscription();

  constructor(private fb: UntypedFormBuilder,
    private leaveApi: MarketingserviceService) {

    this.form = this.fb.group({
      hospital_name: ['', [Validators.required]],
      employeeId: ['', [Validators.required]],
      hospital_type: ['', [Validators.required]],
      employee_name: ['', [Validators.required]],
      discussion_notes: ['', [Validators.required]],
      interest_level: ['', [Validators.required]],
      followup_date: ['', [Validators.required]],
      mobile_number: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.sub.add(
      this.form.valueChanges.subscribe(() => {

      })
    );

    this.empId = localStorage.getItem('emp_id');
    this.employee_name = localStorage.getItem('usr_nm');
  }

  employee_name: any;
  empId: any;
  isInvalid(ctrlName: string): boolean {
    const c = this.form.get(ctrlName);
    return !!(c && c.touched && c.invalid);
  }

  onFileChange(ev: Event): void {
    const input = ev.target as HTMLInputElement;
    const f = input.files && input.files.length ? input.files[0] : null;

    this.file = null;
    this.fileName = '';

    if (!f) return;

    const allowed = ['application/pdf', 'image/png', 'image/jpeg'];
    if (allowed.indexOf(f.type) === -1) {
      alert('Only PDF, JPG, PNG allowed');
      input.value = '';
      return;
    }

    const maxMB = 5;
    if (f.size > maxMB * 1024 * 1024) {
      alert(`File size must be <= ${maxMB} MB`);
      input.value = '';
      return;
    }

    this.file = f;
    this.fileName = f.name;
  }



  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    var data = {
      employee_name: this.employee_name,
      employeeId: this.empId,
      hospital_type: this.form.value.hospital_type,
      discussion_notes: this.form.value.discussion_notes,
      mobile_number: this.form.value.mobile_number,
      hospital_name: this.form.value.hospital_name,
      interest_level: this.form.value.interest_level,
      followup_date: this.form.value.followup_date,
      
    };

    this.submitting = true;

    this.leaveApi.visitform(data).subscribe({
      next: (res) => {
        this.submitting = false;
        alert('submitted!');
        this.resetForm();
      },
      error: (err) => {
        this.submitting = false;
        console.error(' create error:', err);
        alert('Failed to submit');
      }
    });
  }

  resetForm(): void {
    this.form.reset({
      hospital_name: '',
      hospital_type: '',
      mobile_number: '',
      interest_level: '',
      followup_date: '',
      discussion_notes: ''
    });
    this.file = null;
    this.fileName = '';

  }
  cancel(): void {
    this.resetForm();
  }
}