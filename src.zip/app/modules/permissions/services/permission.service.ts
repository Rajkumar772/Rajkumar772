import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { map } from 'rxjs/operators';
import { LoginService } from 'src/app/core/services/login.service';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  PermissionApi = environment.emptyURL; 
  private alertShown: boolean = false;
  private secretKey = environment.secretKey;
  constructor(private http: HttpClient, private loginservice: LoginService) { }
  private handleResponse(res: any) {
    if ((res.status === 401 || res.status === 403) && !this.alertShown) {
      this.alertShown = true;
      alert(res.msg);
      this.loginservice.logout();
      return null;
    }
    return res;
  }

  
  encryptPayload(data: any): string {
    let plaintext = JSON.stringify(data);
    const blockSize = 16;
    const paddingSize = blockSize - (plaintext.length % blockSize);
    plaintext += String.fromCharCode(paddingSize).repeat(paddingSize);
    const secretKey = CryptoJS.enc.Utf8.parse(this.secretKey);
    const encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plaintext), secretKey, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.NoPadding,
    });
    return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
  }

  signPayload(encryptedPayload: string): string {
    const secretKey = CryptoJS.enc.Utf8.parse(this.secretKey); 
    return CryptoJS.HmacSHA256(encryptedPayload, secretKey).toString(CryptoJS.enc.Hex);
  }

  sucessAlert(message) {
    Swal.fire({
      icon: 'success',
      title: message,
      showConfirmButton: false,
      timer: 1500
    })
  }

  errorAlert() {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      timer: 1500
    })
  }


  errorMessageAlert(message) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: message,
      showCloseButton: true,
      showCancelButton: false,
      showConfirmButton: true,
      timer: 1500
    })
  }




  getModules(id) {
    return this.http.get<any>(this.PermissionApi + `getModules/` + id).pipe(map(res => {
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }
  submitAllPermissionsData(data) {
    return this.http.post<any>(this.PermissionApi + `submitpermissions`, data).pipe(map(res => {
      this.sucessAlert('Permissions Added Sucessfully');
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }

  deleteUsers(id) {
    return this.http.get<any>(this.PermissionApi + `deleteUsers/` + id).pipe(map(res => {
      this.sucessAlert('User Deleted Sucessfully');
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }

  deletePermissions(data) {
    const encryptedPayload = this.encryptPayload(data);
    const signature = this.signPayload(encryptedPayload);
    const payload = { encryptedPayload, signature };
    return this.http.post<any>(this.PermissionApi + `deletePermissions`, data).pipe(map(res => {
      this.sucessAlert('Permissions Deleted Sucessfully');
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }

  getmodulelistdata(usr_id) {
    return this.http.get<any>(this.PermissionApi + `getmodulelistdetails/` + usr_id)
  }
  userpermissionget() {
    return this.http.get<any>(this.PermissionApi + `userpermissiongetdata`).pipe(map(res => {
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }


  userpermission(p: any) {
    return this.http.get<any>(this.PermissionApi + `userpermissionget/` + p).pipe(map(res => {
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }

  submituserpermissions(usermenudata) {
    const encryptedPayload = this.encryptPayload(usermenudata);
    const signature = this.signPayload(encryptedPayload);
    const payload = { encryptedPayload, signature };
    return this.http.post<any>(this.PermissionApi + `postusermenulist`, payload)
  }

  addUsers(user) {
    const encryptedPayload = this.encryptPayload(user);
    const signature = this.signPayload(encryptedPayload);
    const payload = { encryptedPayload, signature };
    return this.http.post<any>(this.PermissionApi + `addUsers`, payload).pipe(map(res => {
      return this.handleResponse(res);
    }, error => {
      this.errorAlert();
      return error;
    }));
  }

}
