import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from '../services/login.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard  {

  constructor( private loginService: LoginService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      // const currentUser = this.loginService.currentUserValue;

      if (localStorage.getItem('currentUser')) {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
      }else{
        var currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      }

      if (currentUser) {
          // logged in so return true
          return true;
      }
      // not logged in so redirect to login page with the return url
      this.router.navigate(['/auth/reset-password']);
      return false;
  }
  }


