import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { LoginModel } from '../model/login.model';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';


var LoginApi = environment.emptyURL;

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private secretKey = environment.secretKey;
  private currentUserSubject: BehaviorSubject<LoginModel>;
  public currentUser: Observable<LoginModel>;
  loginData: LoginModel;

  constructor(private http: HttpClient, private router: Router) {
    this.currentUserSubject = new BehaviorSubject<LoginModel>(JSON.parse(sessionStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): LoginModel {
    return this.currentUserSubject.value;
  }


  encryptPayload(data: any): string {
    let plaintext = JSON.stringify(data);
    const blockSize = 16;
    const paddingSize = blockSize - (plaintext.length % blockSize);
    plaintext += String.fromCharCode(paddingSize).repeat(paddingSize);
    const secretKey = CryptoJS.enc.Utf8.parse(this.secretKey);
    const encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plaintext), secretKey, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.NoPadding,
    });
    return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
  }

  decryptPayload(encryptedData: string): any {
    try {
      const secretKey = CryptoJS.enc.Utf8.parse(this.secretKey);
      const bytes = CryptoJS.AES.decrypt(encryptedData, secretKey, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.NoPadding,
      });

      let decrypted = bytes.toString(CryptoJS.enc.Utf8);

      if (!decrypted) {
        console.error("❌ Decryption returned empty string!");
        return null;
      }
      const paddingSize = decrypted.charCodeAt(decrypted.length - 1);
      if (paddingSize < 1 || paddingSize > 16) {
        console.warn("⚠️ Padding size is invalid, skipping padding removal.");
      } else {
        decrypted = decrypted.slice(0, -paddingSize);
      }
      try {
        return JSON.parse(decrypted);
      } catch (jsonError) {
        console.error("❌ Failed to parse decrypted JSON:", jsonError);
        return null;
      }
    } catch (error) {
      console.error("❌ Decryption Error:", error);
      return null;
    }
  }

  signPayload(encryptedPayload: string): string {
    const secretKey = CryptoJS.enc.Utf8.parse(this.secretKey);
    return CryptoJS.HmacSHA256(encryptedPayload, secretKey).toString(CryptoJS.enc.Hex);
  }


  getdashotp(phone: any) {
    const encryptedPayload = this.encryptPayload(phone);
    const signature = this.signPayload(encryptedPayload);
    const payload = { encryptedPayload, signature };
    return this.http.post<any>(LoginApi + 'getdashotp', payload)
  }
  errorMessageAlert(message) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: message,
      showCloseButton: true,
      showCancelButton: false,
      showConfirmButton: true,
      timer: 1500
    })
  }
  logout() {
    sessionStorage.removeItem('currentUser');
    sessionStorage.clear();
    localStorage.removeItem('currentUser');
    localStorage.clear();
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/reset-password']);
  }


  login1(signInData: LoginModel) {
    const encryptedPayload = this.encryptPayload(signInData);
    const signature = this.signPayload(encryptedPayload);
    const payload = { encryptedPayload, signature };
    return this.http.post<any>(LoginApi + 'getUserDatapass', payload).pipe(
      map(user => {
        // ✅ SUCCESS response (encrypted)
        if (user?.encryptedData && user?.signature) {
          const calculatedSignature = this.signPayload(user.encryptedData);
          if (calculatedSignature !== user.signature) {
            this.errorMessageAlert('❌ Response Signature Mismatch');
            return [];
          }

          const DecryptedData: any = this.decryptPayload(user.encryptedData);

          // ✅ permissions check
          if (!DecryptedData?.data || !DecryptedData.data.length) {
            this.errorMessageAlert("You don’t have any permissions. Please contact Admin.");
            return [];
          }

          this.loginData = DecryptedData.data;
          sessionStorage.setItem('Module_id', '0');

          // rememberme can be "" so treat truthy only
          const remember = !!signInData.rememberme;

          if (remember) {
            localStorage.setItem('currentUser', JSON.stringify(this.loginData));
            localStorage.setItem('user_id', DecryptedData.usr_data?.[0]?.id);
          } else {
            sessionStorage.setItem('currentUser', JSON.stringify(this.loginData));
            sessionStorage.setItem('user_id', DecryptedData.usr_data?.[0]?.id);
          }

          const currentTime = new Date().getTime();
          localStorage.setItem('cts', currentTime.toString());
          localStorage.setItem('user_id', DecryptedData.usr_data?.[0]?.id);
          localStorage.setItem('usr_nm', DecryptedData.usr_data?.[0]?.name);
          localStorage.setItem('role_type', DecryptedData.usr_data?.[0]?.role_type);
          localStorage.setItem('department', DecryptedData.usr_data?.[0]?.department);
          localStorage.setItem('designations', DecryptedData.usr_data?.[0]?.designations);
          localStorage.setItem('emp_id', DecryptedData.usr_data?.[0]?.emp_id);
          localStorage.setItem('raju30', DecryptedData.raju30);

          this.currentUserSubject.next(this.loginData);
          return this.loginData;
        }
        if (user?.status) {
          this.errorMessageAlert(user.message || 'Login failed.');
          return [];
        }
        this.errorMessageAlert('Unexpected server response. Please try again.');
        return [];
      }),

      catchError(error => {
        if (error?.status === 400) {
          this.errorMessageAlert(error.error?.message || 'Invalid request. Please try again.');
        } else if (error?.status === 401) {
          // ✅ IMPORTANT: invalid credentials / invalid signature
          this.errorMessageAlert(error.error?.message || 'Invalid Username or Password');
        } else if (error?.status === 202) {
          // if any old API still uses 202
          this.errorMessageAlert('Invalid Username or Password');
        } else if (error?.status === 403) {
          this.errorMessageAlert('Access denied.');
        } else if (error?.status === 429) {
          this.errorMessageAlert(error.error?.message || 'Too many attempts. Please try again later.');
        } else if (error?.status === 500) {
          this.errorMessageAlert('Server Error! Please try again later.');
        } else {
          this.errorMessageAlert('Network/Server error. Please try again.');
        }

        return of(null);
      })
    );
  }
}
